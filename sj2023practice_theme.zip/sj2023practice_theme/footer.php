	<div id="footer">
		<span id="generator-link"><a href="http://wordpress.org/" title="WordPress" rel="generator">WordPress</a></span>
		<span class="meta-sep">|</span>
		<span id="theme-link"><a href="http://google.com/" title="Googlerino" rel="designer">Googlerino</a></span>
	</div><!-- #footer -->

</div><!-- #wrapper .hfeed -->

<?php wp_footer() ?>

</body>
</html>