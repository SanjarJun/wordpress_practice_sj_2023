<div id="sidebar" class="sidebar">

		<h3>Search</h3>
		<form id="searchform" method="get" action="<?php bloginfo('home') ?>">
                    <div>
                    <input id="s" name="s" class="text-input" type="text" value="<?php the_search_query() ?>" size="10" tabindex="11" accesskey="S" />
                    <input id="searchsubmit" class="submit-button" name="searchsubmit" type="submit" value="Go" tabindex="12" />
                    </div>
        </form>
        <br />

		

		<ul>
<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : // begin sidebar widgets ?>

    		
			<li id="categories">
				<h3>Categories</h3>
				<ul>
<?php wp_list_categories('title_li=&show_count=0&hierarchical=1') ?> 

				</ul>
			</li>
            
            <li id="archives">
				<h3>Archives</h3>
				<ul>
<?php wp_get_archives('type=monthly') ?>

				</ul>
			</li>

			<li id="rss-links">
				<h3>RSS Feeds</h3>
				<ul>
					<li><a href="<?php bloginfo('rss2_url') ?>" title="<?php echo wp_specialchars(bloginfo('name'), 1) ?> Posts RSS feed" rel="alternate" type="application/rss+xml">All posts</a></li>
					<li><a href="<?php bloginfo('comments_rss2_url') ?>" title="<?php echo wp_specialchars(bloginfo('name'), 1) ?> Comments RSS feed" rel="alternate" type="application/rss+xml">All comments</a></li>
				</ul>
			</li>

			<li id="meta">
				<h3>Meta</h3>
				<ul>
					<?php wp_register() ?>
					<li><?php wp_loginout() ?></li>
					<?php wp_meta() ?>
				</ul>
			</li>
		
<?php endif; // end sidebar widgets  ?>
		</ul>
		
</div> <!-- #sidebar .sidebar -->