<?php get_header() ?>

	<div id="container">
		<div id="content">

			

<?php while ( have_posts() ) : the_post() ?>
                        
			<div id="post-<?php the_ID() ?>" class="postbox">
				<h2 class="entry-title"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h2>
				<div class="entry-date"><?php the_time('l, F jS, Y') ?> at <?php the_time() ?></div>
				<div class="entry-content">
<?php the_content('Read More <span class="meta-nav">&raquo;</span>') ?>

				<?php wp_link_pages('before=<div class="page-link">' . 'Pages:'. '&after=</div>') ?>
				</div>
				<div class="entry-meta">
					<span class="author vcard"><?php printf( ' %s', '<a class="url fn n" href="' . get_author_link( false, $authordata->ID, $authordata->user_nicename ) . '" title="' . sprintf( 'View all posts by %s', $authordata->display_name ) . '">' . get_the_author() . '</a>' ) ?> </span>
					<span class="cat-links"><?php printf( ' %s',  get_the_category_list(', ') ) ?></span>
					<?php the_tags( '<span class="tag-links"> ',  ", ", "</span>\n\t\t\t\t\t\n" ) ?>
<?php edit_post_link( 'Edit', "\t\t\t\t\t<span class=\"edit-link\">", "</span>\n\t\t\t\t\t\n" ) ?>
					<span class="comments-link"><?php comments_popup_link( 'Comments (0)','Comments (1)', 'Comments (%)') ?> </span>
				</div>
			</div><!-- .postbox -->

<?php comments_template() ?>

<?php endwhile; ?>

			<?php if (function_exists('wp_pagenavi')) : ?>
		<div id="wp-nav">
			<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?><br />
		</div>
		<?php else : ?>
		<div class="nav">
			<div class="nleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="nright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>
		<?php endif; ?>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>