<?php





if ( function_exists('register_sidebar') )

	register_sidebar(array(

        'before_widget' => '<li id="%1$s" class="widget %2$s">',

        'after_widget' => '</li>',

        'before_title' => '<h3>',

        'after_title' => '</h3>',

    ));



function mytheme_comment($comment, $args, $depth) {

   $GLOBALS['comment'] = $comment; ?>

   <li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">

     <div id="div-comment-<?php comment_ID(); ?>">

      <?php if ($comment->comment_approved == '0') : ?>

         <em><?php _e('Your comment is awaiting moderation.') ?></em>

         <br />

      <?php endif; ?>



      <?php comment_type(__(' '), __('Trackback'), __('Pingback')); ?>

 <span class="author"><?php comment_author_link() ?></span> &#8212; <?php comment_date() ?> @ <a href="#comment-<?php comment_ID() ?>"><?php comment_time() ?></a> <?php edit_comment_link(__(" Edit"), ' |'); ?>

	<?php echo get_avatar( $comment, 32 ); ?>

	<?php comment_text() ?>



      <div class="reply">

         <?php comment_reply_link(array_merge( $args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>

      </div>

      </div>

<?php  

} 



?>

