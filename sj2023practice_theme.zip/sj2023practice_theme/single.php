<?php get_header() ?>

	<div id="container">
		<div id="content">

<?php the_post() ?>

			<div id="post-<?php the_ID() ?>" class="postbox">
				<h2 class="entry-title"><?php the_title() ?></h2>
				<div class="entry-content">
                                   <div class="entry-top">
					<span class="entry-date"><?php the_time('F jS, Y') ?> at <?php the_time() ?> </span>
					    <span class="cat-links"><?php the_category(', ') ?></span>  <span class="tag-links"> <?php the_tags( ' ', ', '); ?> </span></div>
                                <?php the_content() ?>

<?php wp_link_pages('before=<div class="page-link">' .'Pages:' . '&after=</div>') ?>
				</div>
				<div class="entry-meta">
					<span class="entry-rss">
					Entry <?php post_comments_feed_link('RSS 2.0'); ?> feed </span> 

<?php if ( ('open' == $post->comment_status) && ('open' == $post->ping_status) ) : // Comments and trackbacks open ?>
                 <a class="trackback-link" href="<?php trackback_url(); ?>" title="Trackback URL for your post" rel="trackback">Trackback</a> 
		<a class="comments-link" href="#respond" title="Post a comment">Post a comment</a>   
<?php elseif ( !('open' == $post->comment_status) && ('open' == $post->ping_status) ) : // Only trackbacks open ?>
					Comments are closed, but you can leave a trackback: <a class="trackback-link" href="<?php trackback_url(); ?>" title="Trackback URL for your post" rel="trackback">Trackback URL</a>.
<?php elseif ( ('open' == $post->comment_status) && !('open' == $post->ping_status) ) : // Only comments open ?>
					Trackbacks are closed, but you can <a class="comment-link" href="#respond" title="Post a comment">post a comment</a>.
<?php elseif ( !('open' == $post->comment_status) && !('open' == $post->ping_status) ) : // Comments and trackbacks closed ?>
					Both comments and trackbacks are currently closed.
<?php endif; ?>
<?php edit_post_link( 'Edit', "\n\t\t\t\t\t<span class=\"edit-link\">", "</span>" ) ?>

				</div>
			</div><!-- .post -->
           <?php if (function_exists('wp_related_posts')) : ?> 
               <div class="posts_lists">
               <?php wp_related_posts(""); ?>
               </div>
           <?php endif; ?>
			<div id="nav-below" class="navigation">
				<div class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav"></span> %title' ) ?></div>
				<div class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav"></span>' ) ?></div>
			</div><br />

<?php comments_template() ?>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>