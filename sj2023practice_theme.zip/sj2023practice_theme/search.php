<?php get_header() ?>

	<div id="container">
		<div id="content">

<?php if (have_posts()) : ?>

		<h2 class="page-title">Search Results for: <?php the_search_query() ?></h2>

<?php while ( have_posts() ) : the_post(); ?>
            
				<div id="post-<?php the_ID() ?>" class="postbox">
				<h2 class="entry-title"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h2>
				<div class="entry-date"><?php the_time('l, F jS, Y') ?> at <?php the_time() ?></div>
				<div class="entry-content">
<?php the_content('Read More <span class="meta-nav">&raquo;</span>') ?>

				<?php wp_link_pages('before=<div class="page-link">' . 'Pages:'. '&after=</div>') ?>
				</div>
				<div class="entry-meta">
					<span class="author vcard"><?php printf( ' %s', '<a class="url fn n" href="' . get_author_link( false, $authordata->ID, $authordata->user_nicename ) . '" title="' . sprintf( 'View all posts by %s', $authordata->display_name ) . '">' . get_the_author() . '</a>' ) ?> </span>
					<span class="cat-links"><?php printf( ' %s',  get_the_category_list(', ') ) ?></span>
					<?php the_tags( '<span class="tag-links"> ',  ", ", "</span>\n\t\t\t\t\t\n" ) ?>
<?php edit_post_link( 'Edit', "\t\t\t\t\t<span class=\"edit-link\">", "</span>\n\t\t\t\t\t\n" ) ?>
					<span class="comments-link"><?php comments_popup_link( 'Comments (0)','Comments (1)', 'Comments (%)') ?> </span>
				</div>
			</div><!-- .postbox -->

<?php endwhile; ?>

			<div id="navigation">
				<div class="nav-previous"><?php next_posts_link('&laquo; Older Entries') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
			</div>

<?php else : ?>

			<div id="post-0" class="noresults post">
				<h2 class="entry-title">Nothing Found</h2>
				<div class="entry-content">
					<p>Sorry, but nothing matched your search criteria. I guest you may like the latest 5 posts:</p>
                    <ol>
                    <?php $my_query = new WP_Query('showposts=5');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>
                    	<li><h3><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>" rel="bookmark"><?php the_title() ?></a></h3></li>
                    <?php endwhile; ?>
                    </ol>
                    <p>If not, Please try again with some different keywords:</p>
				
				<form id="noresults-searchform" method="get" action="<?php bloginfo('home') ?>">
					<div>
						<input id="noresults-s" class="text-input" name="s" type="text" value="<?php the_search_query() ?>" size="40" />
						<input id="noresults-searchsubmit" class="submit-button" name="searchsubmit" type="submit" value="Find" />
					</div>
				</form>
                
                </div>
			</div><!-- .post -->

<?php endif; ?>

		</div><!-- #content -->
	</div><!-- #container -->

<?php get_sidebar() ?>
<?php get_footer() ?>